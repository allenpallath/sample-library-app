import * as i0 from '@angular/core';
import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

class HelloWorldComponent {
    constructor() { }
    ngOnInit() {
    }
}
HelloWorldComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: HelloWorldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
HelloWorldComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.2.7", type: HelloWorldComponent, selector: "app-hello-world", ngImport: i0, template: "<p>hello-world works!</p>\n", styles: [""] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: HelloWorldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-hello-world', template: "<p>hello-world works!</p>\n", styles: [""] }]
        }], ctorParameters: function () { return []; } });

class AppComponent {
    constructor() {
        this.title = 'basic';
    }
}
AppComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: AppComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
AppComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.2.7", type: AppComponent, selector: "app-root", ngImport: i0, template: "<app-hello-world>\r\n    </app-hello-world>", styles: [""], components: [{ type: HelloWorldComponent, selector: "app-hello-world" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: AppComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-root', template: "<app-hello-world>\r\n    </app-hello-world>", styles: [""] }]
        }] });

class AppModule {
}
AppModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: AppModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
AppModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: AppModule, bootstrap: [AppComponent], declarations: [AppComponent,
        HelloWorldComponent], imports: [BrowserModule] });
AppModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: AppModule, providers: [], imports: [[
            BrowserModule
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: AppModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        AppComponent,
                        HelloWorldComponent
                    ],
                    imports: [
                        BrowserModule
                    ],
                    providers: [],
                    bootstrap: [AppComponent]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AppComponent, AppModule, HelloWorldComponent };
//# sourceMappingURL=basic-lib.mjs.map
