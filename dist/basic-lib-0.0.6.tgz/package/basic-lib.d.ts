/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="basic-lib" />
export * from './public_api';
