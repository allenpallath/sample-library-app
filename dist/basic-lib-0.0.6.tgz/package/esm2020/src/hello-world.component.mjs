import { Component } from '@angular/core';
import * as i0 from "@angular/core";
export class HelloWorldComponent {
    constructor() { }
    ngOnInit() {
    }
}
HelloWorldComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: HelloWorldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
HelloWorldComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.2.7", type: HelloWorldComponent, selector: "app-hello-world", ngImport: i0, template: "<p>hello-world works!</p>\n", styles: [""] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: HelloWorldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-hello-world', template: "<p>hello-world works!</p>\n", styles: [""] }]
        }], ctorParameters: function () { return []; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVsbG8td29ybGQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2hlbGxvLXdvcmxkLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uL3NyYy9oZWxsby13b3JsZC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFVLE1BQU0sZUFBZSxDQUFDOztBQU9sRCxNQUFNLE9BQU8sbUJBQW1CO0lBRTlCLGdCQUFnQixDQUFDO0lBRWpCLFFBQVE7SUFDUixDQUFDOztnSEFMVSxtQkFBbUI7b0dBQW5CLG1CQUFtQix1RENQaEMsNkJBQ0E7MkZETWEsbUJBQW1CO2tCQUwvQixTQUFTOytCQUNFLGlCQUFpQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1oZWxsby13b3JsZCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9oZWxsby13b3JsZC5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL2hlbGxvLXdvcmxkLmNvbXBvbmVudC5jc3MnXVxufSlcbmV4cG9ydCBjbGFzcyBIZWxsb1dvcmxkQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcblxuICBjb25zdHJ1Y3RvcigpIHsgfVxuXG4gIG5nT25Jbml0KCk6IHZvaWQge1xuICB9XG5cbn1cbiIsIjxwPmhlbGxvLXdvcmxkIHdvcmtzITwvcD5cbiJdfQ==