import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class HelloWorldComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HelloWorldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HelloWorldComponent, "app-hello-world", never, {}, {}, never, never>;
}
