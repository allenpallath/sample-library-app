import { Component } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "./hello-world.component";
export class AppComponent {
    constructor() {
        this.title = 'basic';
    }
}
AppComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: AppComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
AppComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.2.7", type: AppComponent, selector: "app-root", ngImport: i0, template: "<app-hello-world>\r\n    </app-hello-world>", styles: [""], components: [{ type: i1.HelloWorldComponent, selector: "app-hello-world" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.2.7", ngImport: i0, type: AppComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-root', template: "<app-hello-world>\r\n    </app-hello-world>", styles: [""] }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9hcHAuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vc3JjL2FwcC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDOzs7QUFPMUMsTUFBTSxPQUFPLFlBQVk7SUFMekI7UUFNRSxVQUFLLEdBQUcsT0FBTyxDQUFDO0tBQ2pCOzt5R0FGWSxZQUFZOzZGQUFaLFlBQVksZ0RDUHpCLDZDQUNzQjsyRkRNVCxZQUFZO2tCQUx4QixTQUFTOytCQUNFLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLXJvb3QnLFxuICB0ZW1wbGF0ZVVybDogJy4vYXBwLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vYXBwLmNvbXBvbmVudC5jc3MnXVxufSlcbmV4cG9ydCBjbGFzcyBBcHBDb21wb25lbnQge1xuICB0aXRsZSA9ICdiYXNpYyc7XG59XG4iLCI8YXBwLWhlbGxvLXdvcmxkPlxyXG4gICAgPC9hcHAtaGVsbG8td29ybGQ+Il19